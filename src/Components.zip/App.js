
import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'

import TopNavbar from './Components/TopNavBar';
import Footer from './Components/Footer';
import Listing from './Components/Listing';
import Sidebar from './Components/Sidebar';

const App = () => {
  return (
    <div>
        <div>
        <TopNavbar/>
    </div>
    <div class="container" style={{marginTop:"8rem"}}>
        <div class="row">
            <div class="col-md-3">
            <Sidebar/>
            </div>
            <div class="col-md-9">
            <Listing/>
            </div>
    </div>

    </div>
        <div>
        <Footer/>
        </div> 
    </div>
  )
}

export default App
