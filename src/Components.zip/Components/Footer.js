import React from 'react'
import "../../src/App.css"


const Footer = () => {
  return (
    <div class="footer">
      <p>@Copyright Intrakraft 2017.All rights reserved.</p>
    </div>
  )
}

export default Footer
