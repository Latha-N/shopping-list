        import React,{useState,useEffect} from "react";
        import image1 from '../images/image1.jpg'
        import image2 from '../images/image2.jpg'
        import image3 from '../images/image3.jpg'
        import image4 from '../images/image4.jpg'
        import image5 from '../images/image5.jpg'
        import image10 from '../images/image10.jpg'
        import image7 from '../images/image7.jpg'
        import image8 from '../images/image8.jpg'
        import image9 from '../images/image9.jpg'

        const Listing = () => {

        return (
            <div>
                <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item ">Home</li>
                    <li class="breadcrumb-item">Brands</li>
                    <li class="breadcrumb-item">Jack & Jones</li>
                    <li class="breadcrumb-item">Catalogue</li>
                    </ol>
                </nav>
                <div>
                <ul class="nav">
            	<li class="nav-item" style={{margin:"5px"}}>
            		<div class="alert alert-dismissible fade show border" style={{borderRadius:"25px"}}>
					    <button type="button" class="close" data-dismiss="alert">&times;</button>
					    Men
					 </div>
            	</li>
            	<li class="nav-item" style={{margin:"5px"}}>
            		<div class="alert alert-dismissible fade show border" style={{borderRadius:"25px"}}>
					    <button type="button" class="close" data-dismiss="alert">&times;</button>
					    Women
					 </div>
            	</li>
            	<li class="nav-item" style={{margin:"5px"}}>
            		<div class="alert alert-dismissible fade show border" style={{borderRadius:"25px"}}>
					    <button type="button" class="close" data-dismiss="alert">&times;</button>
					    Kids
					 </div>
            	</li>
            	<li class="nav-item" style={{margin:"5px"}}>
            		<div class="alert alert-dismissible fade show border" style={{borderRadius:"25px"}}>
					    <button type="button" class="close" data-dismiss="alert">&times;</button>
					    New
					 </div>
            	</li>
            	<li class="nav-item" style={{margin:"5px"}}>
            		<a href="#" class="nav-link"><u>Clear All</u></a>
            	</li>	
            </ul>
  
            </div>
                <div class="row">
                <div class="card col-md-4 img-fluid jens">
                <img src={image1} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>Lace insert Velveteen Black Dress</b></h5>
                    <h5 class="card-title">MRP-1249 <del>cost-945</del></h5>
                    <p class="card-text"><span class="text-primary">30% off</span> <b>cost-661</b></p>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image2} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>Women blue jeans</b></h5>
                    <h5 class="card-title">MRP-1000 cost-945</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image3} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>Alan Jones ClothingMen's Fleece Hooded Hoodie</b></h5>
                    <h5 class="card-title">MRP-1249 cost-945</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image4} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>Alan Jones ClothingSolid Taped Cotton Zipper </b></h5>
                    <h5 class="card-title">MRP-1299 cost-999</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image5} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>NammaBabyCotton Front Open Full Sleeves Jhabla Vest- Tshirt - </b></h5>
                    <h5 class="card-title">MRP-699 cost-599</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image10} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>NammaBabyCotton Front Open Full Sleeves Jhabla Vest- Tshirt </b></h5>
                    <h5 class="card-title">MRP-999 cost-599</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image7} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b> Front Open Full Sleeves Jhabla Vest- Tshirt - </b></h5>
                    <h5 class="card-title">MRP-888 cost-859</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image2} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>NammaBabyCotton Front Open  </b></h5>
                    <h5 class="card-title">MRP-799 cost-399</h5>
                </div>
                </div>

                <div class="card col-md-4 img-fluid jens">
                <img src={image1} width="100%" />
                <div class="card-body">
                <h5 class="card-title"><b>linenaffairs Baby Washcloths for Newborn  </b></h5>
                    <h5 class="card-title">MRP-799 cost-499</h5>
                </div>
                </div>
                
                <div class="card col-md-4 img-fluid jens">
                <h5 class="card-header">Lace insert Velveteen Black Dress</h5>
                <img src={image9} width="100%" />
                <div class="card-body">
                    <h5 class="card-title">MRP-1249 <del>cost-945</del></h5>
                    <p class="card-text"><span class="text-primary">30% off</span> <b>cost-661</b></p>
                </div>
                </div>
                </div>
                        
                    
            </div>
        )
        }

        export default Listing
