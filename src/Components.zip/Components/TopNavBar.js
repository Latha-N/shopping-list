import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../src/App.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faShoppingBag, faBell } from '@fortawesome/free-solid-svg-icons'
import intrakraft from '../intrakraft.png'
import logo2 from '../logo2.png'

const TopNavbar = () => {

  return (
  
    <div>
        <nav className="navbar navbar-expand-sm fixed-top " style={{background:'#fff',borderBottom:'2px solid #dccccc45',display:'flex',flexDirection:'row',justifyContent:'space-between'}}>
    <a className="navbar-brand" href="#" style={{listStyle:'none',color:'black'}}>
      <div style={{display:'flex',flexDirection:'row'}}>
       <img src={intrakraft} width="60px" height="60px" />
           <div style={{display:'flex',flexDirection:'column',marginLeft:'10px'}}>
               <h2 style={{fontWeight:'bold',opacity:1}}>Intrakarft</h2>
               <p style={{fontSize:'14px',opacity:0.8}}>Correct. Interact. Transact.</p>
           </div>
      </div>
   </a>
   <ul className="navbar-nav" >
       <li className="nav-item mr-5">
           <a style={{fontSize:'20px',fontWeight:550,opacity:1}} className="nav-link text-dark" href="#">Orders</a>
       </li>
       <li className="nav-item active mr-5">
           <a style={{fontSize:'20px',fontWeight:550,opacity:1}} className="nav-link  text-dark" href="#">Brands</a>
       </li>
       <li className="nav-item mr-5">
           <a style={{fontSize:'20px',fontWeight:550,opacity:1}} className="nav-link  text-dark" href="#">Connections</a>
       </li>
      
       <li className="nav-item mr-5">
           <a className="nav-link" href="#">
               <FontAwesomeIcon icon={faShoppingBag} style={{fontSize:'30',color:'black',opacity:0.3}}/>
           </a>
       </li>
       <li className="nav-item mr-5">
           <a className="nav-link d-flex justify-content-start align-items-start" href="#">
               <FontAwesomeIcon icon={faBell} style={{fontSize:'30',color:'black',opacity:0.3}}/>
               <span class="badge badge-warning text-white">1</span>
           </a>
       </li>
       <li>
       <div style={{display:'flex',flexDirection:'row'}}>
       <img src={logo2} width="60px" height="60px" />
           <div class="dropdown" style={{display:'flex',flexDirection:'column',marginLeft:'0px'}}>
               <h2  class="btn  dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"style={{fontWeight:'bold',opacity:1}}>Welcome<br/> shopper stop</h2>
           </div>
      </div>
    </li>
      
   </ul>

</nav>

    </div>
    
  )
}

export default TopNavbar
